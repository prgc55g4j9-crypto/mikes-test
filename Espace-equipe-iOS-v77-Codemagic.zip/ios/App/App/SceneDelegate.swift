import UIKit
import Capacitor
import WebKit
import UserNotifications

class SceneDelegate: UIResponder, UIWindowSceneDelegate {
    var window: UIWindow?

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = scene as? UIWindowScene else { return }

        window = UIWindow(windowScene: windowScene)
        window?.rootViewController = MikesPushController()
        window?.makeKeyAndVisible()

        SceneDelegateProxy.shared.scene(scene, willConnectTo: session, options: connectionOptions)
    }

    func scene(_ scene: UIScene, openURLContexts URLContexts: Set<UIOpenURLContext>) {
        SceneDelegateProxy.shared.scene(scene, openURLContexts: URLContexts)
    }

    func scene(_ scene: UIScene, continue userActivity: NSUserActivity) {
        SceneDelegateProxy.shared.scene(scene, continue: userActivity)
    }
}

// Bridge accepts only a main-frame request from the fixed HTTPS app origin.
class MikesPushController: CAPBridgeViewController, WKScriptMessageHandler {
    static weak var current: MikesPushController?
    static var token: String?
    static var openPending = false
    override func capacitorDidLoad() {
        Self.current = self
        webView?.configuration.userContentController.add(self, name: "mikesPush")
        let script = WKUserScript(source: "window.addEventListener('load',()=>window.webkit.messageHandlers.mikesPush.postMessage('ready'));", injectionTime: .atDocumentEnd, forMainFrameOnly: true)
        webView?.configuration.userContentController.addUserScript(script)
    }
    func trusted() -> Bool {
        return webView?.url?.scheme == "https" && webView?.url?.host == "espace-equipe.ca"
    }
    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        guard trusted(), message.frameInfo.isMainFrame, message.frameInfo.securityOrigin.host == "espace-equipe.ca", let value = message.body as? String else { return }
        if value == "ready" {
            emitToken(); openNotifications()
            UNUserNotificationCenter.current().getNotificationSettings { settings in
                if settings.authorizationStatus == .authorized || settings.authorizationStatus == .provisional { DispatchQueue.main.async { UIApplication.shared.registerForRemoteNotifications() } }
            }
        } else if value == "enable" {
            UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { allowed, _ in
                DispatchQueue.main.async { if allowed { UIApplication.shared.registerForRemoteNotifications() } else { self.emit("mikes-push-error", detail: [:]) } }
            }
        }
    }
    func emit(_ name: String, detail: [String: String]) {
        guard trusted(), let data = try? JSONSerialization.data(withJSONObject: detail), let json = String(data: data, encoding: .utf8) else { return }
        webView?.evaluateJavaScript("window.dispatchEvent(new CustomEvent('\(name)',{detail:\(json)}));", completionHandler: nil)
    }
    func emitToken() { if let value = Self.token { emit("mikes-push-token", detail: ["provider": "apns", "token": value]) } }
    func openNotifications() {
        guard Self.openPending, trusted() else { return }
        Self.openPending = false
        emit("mikes-push-open", detail: [:])
    }
}
