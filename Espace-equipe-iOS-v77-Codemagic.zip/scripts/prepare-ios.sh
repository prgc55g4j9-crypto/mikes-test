#!/bin/sh
set -eu
sips -z 1024 1024 assets/AppIcon-source.png --out ios/App/App/Assets.xcassets/AppIcon.appiconset/AppIcon-512@2x.png >/dev/null
