# Espace équipe — sources iOS pour Codemagic

L’application charge https://espace-equipe.ca avec Capacitor. Le nom affiché, les icônes, le lancement et le pont de notifications ont été adaptés. L’identifiant ca.mikes.equipe reste inchangé pour conserver la même application Apple.

## Mettre à jour le projet existant

1. Décompresser le paquet et remplacer les sources du dépôt déjà relié à Codemagic, à sa racine : codemagic.yaml, package.json, package-lock.json, capacitor.config.json, ios/, scripts/, www/ et assets/.
2. Dans Codemagic, ouvrir cette application, sélectionner la branche mise à jour et lancer ios-ipa. La signature App Store doit être configurée pour ca.mikes.equipe. Conserver les certificats et clés dans Codemagic, jamais dans le dépôt.
3. Récupérer l’IPA dans les artifacts. Ce workflow ne l’envoie pas automatiquement à App Store Connect. Utiliser l’intégration App Store Connect existante ou Transporter sur Mac pour l’envoyer, puis TestFlight pour l’essayer sur un vrai iPhone.

Le workflow ios-simulator compile sans signature; son résultat ne s’installe pas sur un téléphone.

## État vérifiable

Vérification structurelle locale : node scripts/verify.mjs. Compilation Xcode et essais physiques encore à réaliser. L’interface est chargée à distance et nécessite Internet. Vérifier connexion, erreurs réseau, médias, signatures, notifications, signalement, blocage et suppression sur iPhone avant soumission. Ce paquet ne constitue pas une validation Apple.

La vidéo physique, les comptes fictifs par rôle et les six réponses demandées doivent accompagner la soumission.
