import UIKit
import Capacitor
import WebKit
import UserNotifications

class SceneDelegate: UIResponder, UIWindowSceneDelegate {
    var window: UIWindow?

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = scene as? UIWindowScene else { return }

        window = UIWindow(windowScene: windowScene)
        window?.rootViewController = MikesPushController()
        window?.makeKeyAndVisible()

        SceneDelegateProxy.shared.scene(scene, willConnectTo: session, options: connectionOptions)
    }

    func scene(_ scene: UIScene, openURLContexts URLContexts: Set<UIOpenURLContext>) {
        SceneDelegateProxy.shared.scene(scene, openURLContexts: URLContexts)
    }

    func scene(_ scene: UIScene, continue userActivity: NSUserActivity) {
        SceneDelegateProxy.shared.scene(scene, continue: userActivity)
    }
}

// Bridge accepts only a main-frame request from the fixed HTTPS app origin.
class MikesPushController: CAPBridgeViewController, WKScriptMessageHandler {
    static weak var current: MikesPushController?
    static var token: String?
    static var openPending = false
    private var refreshedRemoteShell = false
    override func capacitorDidLoad() {
        Self.current = self
        webView?.configuration.userContentController.add(self, name: "mikesPush")
        // The page can have finished loading before this script is installed.
        // Signal readiness immediately in that case, otherwise wait for DOM.
        let script = WKUserScript(source: "(()=>{const ready=()=>{try{window.webkit.messageHandlers.mikesPush.postMessage('ready')}catch(_){}};document.readyState==='loading'?document.addEventListener('DOMContentLoaded',ready,{once:true}):ready()})()", injectionTime: .atDocumentEnd, forMainFrameOnly: true)
        webView?.configuration.userContentController.addUserScript(script)
        // A WKWebView can retain an older HTML shell after an App Store
        // update. Reload once from the origin so the current notification
        // bridge and service-worker scripts are used by every staff device.
        if !refreshedRemoteShell {
            refreshedRemoteShell = true
            DispatchQueue.main.async { [weak self] in self?.webView?.reloadFromOrigin() }
        }
    }
    func trusted() -> Bool {
        return webView?.url?.scheme == "https" && webView?.url?.host == "espace-equipe.ca"
    }
    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        guard trusted(), message.frameInfo.isMainFrame, message.frameInfo.securityOrigin.host == "espace-equipe.ca" else { return }
        let value: String
        let badge: Int?
        if let text = message.body as? String {
            value = text
            badge = nil
        } else if let payload = message.body as? [String: Any], let action = payload["action"] as? String {
            value = action
            badge = (payload["count"] as? NSNumber)?.intValue
        } else {
            return
        }
        if value == "ready" {
            emitToken(); openNotifications()
            UNUserNotificationCenter.current().getNotificationSettings { settings in
                if settings.authorizationStatus == .authorized || settings.authorizationStatus == .provisional { DispatchQueue.main.async { UIApplication.shared.registerForRemoteNotifications() } }
            }
        } else if value == "enable" {
            UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { allowed, _ in
                DispatchQueue.main.async { if allowed { UIApplication.shared.registerForRemoteNotifications() } else { self.emit("mikes-push-error", detail: ["reason": "permission"]) } }
            }
        } else if value == "badge", let badge {
            UIApplication.shared.applicationIconBadgeNumber = max(0, min(9999, badge))
        }
    }
    func emit(_ name: String, detail: [String: String]) {
        guard trusted(), let data = try? JSONSerialization.data(withJSONObject: detail), let json = String(data: data, encoding: .utf8) else { return }
        webView?.evaluateJavaScript("window.dispatchEvent(new CustomEvent('\(name)',{detail:\(json)}));", completionHandler: nil)
    }
    func emitToken() { if let value = Self.token { emit("mikes-push-token", detail: ["provider": "apns", "token": value]) } }
    // The WebView owns the authenticated session cookie. Query the true unread
    // count after returning to the app so an old notification cannot leave a
    // red badge behind once the inbox is empty.
    func syncBadge() {
        guard trusted() else { return }
        let script = """
        (()=>fetch('/api/notifications',{cache:'no-store',credentials:'same-origin'})
          .then(response=>response.ok?response.json():null)
          .then(value=>{const count=Number(value?.unread);if(Number.isFinite(count)){window.webkit.messageHandlers.mikesPush.postMessage({action:'badge',count:Math.max(0,Math.min(9999,Math.trunc(count)))})}})
          .catch(()=>{}))();
        """
        webView?.evaluateJavaScript(script, completionHandler: nil)
    }
    func openNotifications() {
        guard Self.openPending, trusted() else { return }
        Self.openPending = false
        emit("mikes-push-open", detail: [:])
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.75) { [weak self] in self?.syncBadge() }
    }
}
